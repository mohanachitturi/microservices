package com.techm.ms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


import com.techm.ms.model.User;

@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	AccountService accountService;
	private static final AtomicLong counter = new AtomicLong();
	
	private  List<User> users = populateDummyUsers();
	
//	static {
//		users = populateDummyUsers();
//	}
	public User findById(long id) {
		for(User user : users) {
			if(user.getId() == id) {
				return user;
			}
		}
//		CustomError customError = new CustomError("Account with id"+id+"not found","Not_Found");
//		throw  customError;
		return null;
	}
	

	
	public User saveUser(User user) {
		for(User userFromDb : users) {
			if(!userFromDb.getName().equals(user.getName())) {
				return null;
				
			}
		}
		users.add(user);
		return user;
	}
	

	 private  List<User> populateDummyUsers(){
		List<User> users = new ArrayList<User>();
	
		//int accountId = (int)accountService.findByName("account1").getId();
		int accountId = 20;
		users.add(new User(counter.incrementAndGet(),"testName1",20,accountId));
		users.add(new User(counter.incrementAndGet(),"testName2",30,accountId));
		users.add(new User(counter.incrementAndGet(),"testtName3",40,accountId));
		return users;
	} 
}
