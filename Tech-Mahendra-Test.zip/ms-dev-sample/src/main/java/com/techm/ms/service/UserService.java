package com.techm.ms.service;


import com.techm.ms.model.User;

public interface UserService {
	public User findById(long id) ;

	public User saveUser(User user) ;
}
