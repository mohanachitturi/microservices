package com.techm.ms.resource;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.ws.rs.core.Link;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.techm.ms.exception.CustomError;
import com.techm.ms.model.Account;
import com.techm.ms.model.User;
import com.techm.ms.model.representation.Resource;
import com.techm.ms.model.representation.ResourceCollection;
import com.techm.ms.service.UserService;

@Controller
public class UserResourceImpl implements UserResource {
private static final AtomicLong counter = new AtomicLong();

@Autowired
UserService userService; 
	

private static String baseUrl = "/users";	


	
	@Override
	public Response createUser(User user) {
		User savedUser  = userService.saveUser(user);
		if(savedUser == null) {
			return Response.noContent().build();
		}
		Link link = Link.fromUri(baseUrl).rel("self").build();		
		Resource<User> resource = new Resource<>(savedUser);
		return Response.ok(resource).links(link).build();
		 		
	}
	@Override
	public Response getUser(Long id) {
			User user =  userService.findById(id);
			if(user == null) {
				return Response.noContent().build();
			}
			Link link = Link.fromUri(baseUrl).rel("self").build();		
			Resource<User> resource = new Resource<>(user);
			return Response.ok(resource).links(link).build();
	}

}
